package com.muzadev.asistenpemrogramanaplikasimobile.adapter;

// TODO jadikan kelas ini mengextend RecyclerView.Adapter<AdpTodo.ViewHolder>
public class AdpTodo {
    // TODO buat objek dengan type Context dengan nama context.
    // TODO buat objek dengan type List<Note> dengan nama noteList.

    // TODO buat sebuah constructor yang hanya mengisi objek context di atas.
    // TODO inisialisasikan objek noteList di atas menjadi new ArrayList<>()

    // TODO buat sebuah method untuk mengisi noteList di atas.

    // TODO uncomment method ini
    /*@NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_todo, parent, false);
        return new ViewHolder(v);
    }*/

   /* @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bindView(noteList.get(position));
    }*/

    // TODO uncomment method ini
   /* @Override
    public int getItemCount() {

        return TODO isikan dengan ukuran noteList;
    }*/

    // TODO uncomment class ini
    /*public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTodoTitle, tvTodoContent;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTodoTitle = itemView.findViewById(R.id.tvTodoTitle);
            tvTodoContent = itemView.findViewById(R.id.tvTodoContent);
        }

        public void bindView(Note note) {
            tvTodoTitle.setText(note.getTitle());
            tvTodoContent.setText(note.getContent());
        }
    }*/
}
