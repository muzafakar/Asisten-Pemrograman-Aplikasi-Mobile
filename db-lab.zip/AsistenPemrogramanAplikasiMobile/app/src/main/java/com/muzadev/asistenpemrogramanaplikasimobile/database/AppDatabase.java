package com.muzadev.asistenpemrogramanaplikasimobile.database;

// TODO ubah class AppDatabase menjadi abstract dan mengextend RoomDatabase
// TODO masukan class Note sebagai table nya
public abstract class AppDatabase {
    // TODO buat sebuah objek noteaDao dengan sifat abstract.

    // TODO buat sebuah objek AppDatabase dengan nama INSTANCE dengan sifat abstract.

    // TODO buat method getInstance untuk mengambil objek databasenya.
}
