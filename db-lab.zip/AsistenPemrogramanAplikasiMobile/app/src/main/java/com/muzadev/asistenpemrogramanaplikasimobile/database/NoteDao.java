package com.muzadev.asistenpemrogramanaplikasimobile.database;

// TODO jadikan interface NoteDao menjadi sebuah Dao
public interface NoteDao {
    // TODO buat sebuah abstract function untuk insert data ke database

    // TODO buat sebuah abstract function untuk membaca data dari database
}
