package com.muzadev.asistenpemrogramanaplikasimobile.model;

// TODO jadikan class Note sebagai table/entitas
public class Note {
    // TODO buat property id
    // TODO jadikan id sebagai primaryKey
    // TODO buat property title
    // TODO buat property content

    // TODO generate constructor, setter, dan getter
}